import java.text.ParseException;
import java.io.*;
import java.util.ArrayList;

public class Reading {

    public Reading() throws ClassNotFoundException, IOException, ParseException { }

    ////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) throws ClassNotFoundException, IOException, ParseException{ Reading.readInformation(); }

    ////////////////////////////////////////////////////////////////////////////////////

    @SuppressWarnings("unchecked")
    public static void readInformation() throws ClassNotFoundException, IOException, ParseException {
        AirlineSystem.Customers = readCustomer("Customer.txt");
        ArrayList<Flight> flights = readFlight("Flight.txt");
        Object[] info = readAirline("Airline.txt", flights);
        AirlineSystem.Airlines = (ArrayList<Airline>)info[0];
        AirlineSystem.allFlights = (ArrayList<Flight>)info[1];
    }

    ////////////////////////////////////////////////////////////////////////////////////

    public static ArrayList<Customer> readCustomer(String filename) throws  ParseException {
        String customers_raw = Reading.readFile(filename);
        ArrayList<Customer> pullArr = new ArrayList<Customer>();
        if (customers_raw.length() == 0) return pullArr;
        //////////////////
        for (String line : customers_raw.split("\n"))
        {
            String[] things = line.split("\t");
            Customer st = new Customer(things[0], things[1], things[2]);
            st.setCheckFlight(readFlight(things[3]));
            st.setFlightFee(Integer.parseInt(things[4]));
            st.setFlightStatus(Boolean.parseBoolean(things[5]));
            pullArr.add(st);
        }
        return pullArr;
    }

    ////////////////////////////////////////////////////////////////////////////////////

    public static ArrayList<Flight> readFlight(String filename) throws ParseException{
        String flights_raw = Reading.readFile(filename);
        ArrayList<Flight> listfl = new ArrayList<Flight>();
        if (flights_raw.length() == 0) return listfl;
        ///////////
        for (String line : flights_raw.split("\n"))
        {
            String[] things = line.split("\t");
            listfl.add(new Flight(things[0], Integer.parseInt(things[1]), things[2]));
        }
        return listfl;
    }

    ////////////////////////////////////////////////////////////////////////////////////

    public static Object[] readAirline(String filename, ArrayList<Flight> flights)throws  ParseException {
        String airline_raw = Reading.readFile("Airline.txt");
        ArrayList<Airline> listLib = new ArrayList<Airline>();
        if (airline_raw.length() == 0) return new Object[] { listLib, flights };
        /////////////
        for (String line : airline_raw.split("\n"))
        {
            String[] things = line.split("\t");
            ArrayList<Flight> checkedFlights = readFlight(things[3]);
            for (Flight fl : checkedFlights) {
                ///////////
                for (Flight fl2 : flights) {
                    ////////////
                    if (fl2.getNum() == fl.getNum()) fl2.setAvailableStatus(true);
                }
            }
            Airline lib = new Airline(things[0], things[1], things[2]);
            listLib.add(lib);
        }
        return new Object[] { listLib, flights };
    }


    ////////////////////////////////////////////////////////////////////////////////////
    public static String readFile(String filename)
    {
        String out = "";
        /////////////
        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(filename)));
            out = "";
            String line = "";
            /////////////
            try {
                //////////////
                while ((line = reader.readLine()) != null) {
                    out += (out.length() == 0 ? "" : "\n") + line;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return out;
    }
}
