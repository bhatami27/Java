import java.io.Serializable;
import java.util.ArrayList;

public class Airline implements Serializable
{
    private String name; //name of the Airline
    private String username; // username of the Airline
    private String password; //password of the Airline

    ////////////////////////////////////////////////////////////////////////////////////
    //con
    public Airline(String nam, String userNam, String pass)
    {
        this.name = nam;
        this.username = userNam;
        this.password = pass;
    }

    //bunch of getter and setter for airline class

    ////////////////////////////////////////////////////////////////////////////////////
    public String getName()
    {return name;}

    ////////////////////////////////////////////////////////////////////////////////////
    public void setName(String n)
    { this.name = n; }

    ////////////////////////////////////////////////////////////////////////////////////
    public String getUserName()
    {return username;}

    ////////////////////////////////////////////////////////////////////////////////////
    public void setUserName(String name)
    { this.username = name; }

    ////////////////////////////////////////////////////////////////////////////////////
    public String getPassword()
    {return password;}

    ////////////////////////////////////////////////////////////////////////////////////
    public void setPassword(String pass)
    { this.password = pass; }

    ////////////////////////////////////////////////////////////////////////////////////
    public void setFlightFee(Customer st, int num)
    {
        if(AirlineSystem.Customers.contains(st))
        {
            int index = AirlineSystem.Customers.indexOf(st);
            AirlineSystem.Customers.get(index).setFlightFee(num);
        }
        ////////////
        else
        {
            System.out.println("ERROR: Customer not found.");
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //add flight
    public void addFlight(Flight bk)
    {
        AirlineSystem.allFlights.add(bk);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //cancel flight
    public void deleteFlight(Flight bk)
    {
        if(AirlineSystem.allFlights.remove(bk))
        { System.out.println("Adding Flight is successful."); }
        ////////////////
        else
        { System.out.println("ERROR: Flight not found."); }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public ArrayList<Flight> getCheckedFlights()
    {
        ArrayList<Flight> out = new ArrayList<Flight>();
        for(Flight bk : AirlineSystem.getFlights())
        {
            ///////////////
            if(!(bk.getAvailableStatus())) //MAKE toString IN Flight
            {
                out.add(bk);
                String Landing = bk.getLanding();
                String TakeOff = bk.getTakeOff();
                int Num = bk.getNum();
                System.out.println("TakeOff: " + TakeOff + " | Landing: " + Landing + " | Num:" + Num);
            }
        }
        return out;
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public String toString()
    {
        return "Name " + getName() + " | " + getUserName() + " | " + getPassword();
    }

}
