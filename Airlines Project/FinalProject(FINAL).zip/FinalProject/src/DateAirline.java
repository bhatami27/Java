import java.util.Calendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateAirline
{
    private int year; // the year
    public static Date currentDate;
    private Date FlightDate; //return date
    private int month; //the month
    private int day; // the day

    ////////////////////////////////////////////////////////////////////////////////////

    public DateAirline(int d, int m, int y) throws ParseException
    {
        this.month = m;
        day = d;
        year = y;
        FlightDate = new Date(year, month, d);
        updateCurrentDate();
    }
    ////////////////////////////////////////////////////////////////////////////////////
    public DateAirline()throws ParseException
    { updateCurrentDate(); }

    ////////////////////////////////////////////////////////////////////////////////////
    public int getMonth()
    {return month;}

    ////////////////////////////////////////////////////////////////////////////////////

    public void setMonth(int m)
    { month = m; }


    ////////////////////////////////////////////////////////////////////////////////////
    public int getDay() {return day;}


    ////////////////////////////////////////////////////////////////////////////////////
    public void setDay(int d)
    { day = d; }

    ////////////////////////////////////////////////////////////////////////////////////
    public int getYear()
    {return year;}

    ////////////////////////////////////////////////////////////////////////////////////
    public void setYear(int y)
    { year = y; }

    ////////////////////////////////////////////////////////////////////////////////////

    public void setFlightDate(Date dt)
    { FlightDate = dt; }

    ////////////////////////////////////////////////////////////////////////////////////
    public String toString()
    { return ("You must pay on: " + day + "/" + month + "/" + year); }

    ////////////////////////////////////////////////////////////////////////////////////
    public Date getFlightDate()
    { return FlightDate; }

    ////////////////////////////////////////////////////////////////////////////////////

    public static void updateCurrentDate() throws ParseException
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String str = sdf.format(Calendar.getInstance().getTime());
        currentDate = new SimpleDateFormat("yyyy-MM-dd").parse(str);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //comparing date
    public static Boolean compareDate(Date d) throws ParseException
    {
        updateCurrentDate();
        if(currentDate.before(d))
        {
            return true;
        }
        return false;
    }

    ////////////////////////////////////////////////////////////////////////////////////

    public static void main(String[] args) throws ParseException
    { }

}
