import java.util.ArrayList;

public class Customer
{
    private String name; //name of the Customer
    private String userName; // name of the userName
    private String password; // name of the password
    private ArrayList<Flight> checkFlight; //list of the Flights that Customer has checked out
    private Boolean FlightStatus; //true = Flight booked and false = not Flight booked
    private int FlightFee; //fee for flight



    ////////////////////////////////////////////////////////////////////////////////////
    //con
    public Customer(String name, String userN, String pass)
    {
        this.name = name;
        this.userName = userN;
        this.password = pass;
        checkFlight = new ArrayList<Flight>();
        FlightStatus = false;
        FlightFee = 0;
    }


    //ABOUT TO BE A BUNCH OF SETTER AND GETTERS FOR CUSTOMER CLASS

    ////////////////////////////////////////////////////////////////////////////////////
    //get customer name
    public String getName()
    { return name; }


    ////////////////////////////////////////////////////////////////////////////////////
    public String getUserName()
    {return userName;}


    ////////////////////////////////////////////////////////////////////////////////////
    public String getPassword()
    {return password;}


    ////////////////////////////////////////////////////////////////////////////////////
    public ArrayList<Flight> getCheckFlight() { return this.checkFlight; }

    ////////////////////////////////////////////////////////////////////////////////////
    public void setCheckFlight(ArrayList<Flight> checkFlight) {
        this.checkFlight = checkFlight;
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public void rentFlight(Flight fl)
    { checkFlight.add(fl); }

    ////////////////////////////////////////////////////////////////////////////////////
    public void turnInFlight(Flight fl)
    {
        if (checkFlight.contains(fl))
        { checkFlight.remove(fl); }
        ////////////
        else
        { System.out.println("Customer has not checked out " + fl.getLanding()); }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public void setFlightStatus(Boolean bool)
    { FlightStatus = bool; }

    ////////////////////////////////////////////////////////////////////////////////////
    public boolean getFlightStatus()
    { return FlightStatus; }

    ////////////////////////////////////////////////////////////////////////////////////
    public int getFlightFee()
    { return FlightFee; }

    ////////////////////////////////////////////////////////////////////////////////////
    public void setFlightFee(int num)
    { FlightFee = num; }


}
