import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.text.ParseException;
final class AirlineSystem implements Serializable
{
    public static ArrayList<Customer> Customers = new ArrayList<Customer>(); //list of Customers in the system
    public static ArrayList<Flight> allFlights = new ArrayList<Flight>(); // list of Flight in the system
    public static ArrayList<Airline> Airlines = new ArrayList<Airline>(); //list of Airline in the system
    public static int totalFlightsBooked;

    ////////////////////////////////////////////////////////////////////////////////////

    public AirlineSystem() throws ParseException
    {
        totalFlightsBooked = 0;
        Random rn = new Random();
        ////////////
        for(int i = 0; i < 100; i++) {
            String generate = "";
            int genLength =  rn.nextInt(19)+1;
            ////////////
            for(int f = 0; f < genLength;f++) { generate += (char) (97 + rn.nextInt(24)); }
            ////////////
            allFlights.add(new Flight("Chicago",i,generate));
        }
        allFlights.add(new Flight("Miami", allFlights.size(), "Nashville"));
        Airlines.add(new Airline("User", "username", "456"));
    }

    ////////////////////////////////////////////////////////////////////////////////////

    //add customer to system (customer file)
    public void addCustomer(Customer st){
        if(!Customers.contains(st)){
            Customers.add(st);
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //delete customer
    public static void deleteCustomer(Customer st){ Customers.remove(st); }

    ////////////////////////////////////////////////////////////////////////////////////
    //sort
    public void sortFlights() //sorts Flights.
    {
        boolean sorted = false;
        while(!sorted) {
            sorted = true;
            /////////////////
            for(int i = 0; i < allFlights.size()-1; i++) {
                String Flight1 = allFlights.get(i).getLanding();
                Flight1 = Flight1.trim().toLowerCase();
                String Flight2 = allFlights.get(i+1).getLanding();
                Flight2 = Flight2.trim().toLowerCase();
                /////////////////
                if(Flight1.compareTo(Flight2) > 0){
                    Flight hold = allFlights.get(i);
                    allFlights.set(i, allFlights.get(i+1));
                    allFlights.set(i+1, hold);
                    sorted = false;
                }
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //Looks for landing locations. if not found return false
    public boolean FlightLandingExist(String Landing) {
        for (Flight Flights : allFlights)
        {
            ///////////////
            if(Flights.getLanding().equals(Landing))
            { return true; }
        }
        return false;
    }


    ////////////////////////////////////////////////////////////////////////////////////
    //see if the take off location is real. if so returns true and if not false
    public boolean FlightTakeOffExist(String TakeOff)
    {
        for (Flight Flights : allFlights)
        /////////////////
        { if(Flights.getTakeOff().equals(TakeOff)) { return true; } }
        /////////////////
        return false;
    }


    ////////////////////////////////////////////////////////////////////////////////////
    //see if the flight num is real. if so returns true and if not false
    public boolean FlightNumExist(int Numz)
    {
        for (Flight Flights : allFlights) { if(Flights.getNum() == Numz) { return true; } }
        /////////////////
        return false;
    }


    ////////////////////////////////////////////////////////////////////////////////////
    //Looks for username. if not found return false
    public boolean usernameExist(String uName)
    {
        for (Customer std : Customers) {
            /////////////////
            if(std.getUserName().equals(uName))
            { return true; }
        }
        /////////////////
        for (Airline libz : Airlines)
        {
            if(libz.getUserName().equals(uName))
            /////////////////
            { return true; }
        }
        /////////////////
        return false;
    }


    ////////////////////////////////////////////////////////////////////////////////////
    //get flights
    public static ArrayList<Flight> getFlights(){
        return allFlights;
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //get customer
    public static ArrayList<Customer> getCustomers(){
        return Customers;
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //add airline
    public static void addAirline(Airline lb){
        Airlines.add(lb);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //search through and return landing location
    public void searchLanding(String Landing){
        int counter = 0;
        for(Flight item : allFlights) {
            /////////////////
            if(item.getLanding().equals(Landing)){
                System.out.println(item.toString());
                counter++;
            }
        }
        /////////////////
        if (counter == 0)
        { System.out.println("Landing not found."); }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    //search through and return take off location
    public void searchTakeOff(String TakeOff){
        int counter = 0;
        for(Flight item : allFlights)
        {
            /////////////////
            if(item.getTakeOff().equals(TakeOff))
            { counter++; System.out.println(item.toString()); }
        }
        /////////////////
        if(counter == 0)
        { System.out.println("No TakeOff found"); }

    }

    ////////////////////////////////////////////////////////////////////////////////////
    //search for num and return num
    public void searchNum(int Num){
        int counter  = 0;
        for(Flight item : allFlights) {
            /////////////////
            if(item.getNum() == Num){ System.out.println(item.toString()); counter++; }
        }
        /////////////////
        if(counter  == 0) { System.out.println("Num not found"); }
        /////////////////
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public Flight getFlight(int isb) {
        for(Flight item : allFlights) {
            /////////////////
            if(item.getNum() == isb) { return item; }
        }
        return null;
    }


    ////////////////////////////////////////////////////////////////////////////////////
    // get airline in array
    public ArrayList<Airline> getAirlines() { return Airlines; }


    ////////////////////////////////////////////////////////////////////////////////////
    //display all
    public void displayAll() {
        sortFlights();
        for(Flight item : allFlights) {
            System.out.println(item);
        }
    }


    ////////////////////////////////////////////////////////////////////////////////////
    //add flight
    public void addFlight(Flight bk) { allFlights.add(bk); }


    ////////////////////////////////////////////////////////////////////////////////////
    public static void main(String[] args) { }
}
