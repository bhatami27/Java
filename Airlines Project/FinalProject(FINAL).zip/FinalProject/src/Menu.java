import java.util.Calendar;
import java.text.ParseException;
import java.io.IOException;
import java.util.Scanner;


public class Menu
{
  private Customer currentCustomer;
  private Airline currentAirline;
  private Flight fl;
  AirlineSystem airSys;
  public Scanner sc = new Scanner(System.in);

  ////////////////////////////////////////////////////////////////////////////////////

  public Menu() throws ParseException
  {
    airSys = new AirlineSystem();
    for(Airline item : airSys.getAirlines()) {
      System.out.println(item);
    }
    /////////////
    try {
      Reading.readInformation();
    } catch (Exception e) {}
    menu();
  }

  ////////////////////////////////////////////////////////////////////////////////////
  //dictate the methods
  public void menu() throws ParseException
  {
    boolean stayMen = true;
    while(stayMen)  {
      System.out.println("Please enter the number of the desired option");
      System.out.println("1. Customer Menu");
      System.out.println("2. Airline Menu");
      System.out.println("3. Close program");

      int n = sc.nextInt(); sc.nextLine();

      if (n == 1)
      { customerMenu(); }
      ////////////
      else if (n == 2)
      { airlineLogin(); }
      ////////////
      else if (n == 3) { stayMen = false; exit(); }
      ////////////
      else { System.out.println("ERROR: Choose a valid option."); }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerMenu() throws ParseException
  {
    boolean stayStMen = true;
    while(stayStMen)  {
      System.out.println("1. Login");
      System.out.println("2. Register");
      System.out.println("3. Back");
      System.out.println("4. Close Program");
      int n = sc.nextInt(); sc.nextLine();

      if (n == 1) { customerLogin(); }
      ////////////
      else if (n == 2) { customerRegister(); }
      ////////////
      else if(n == 3) { stayStMen = false; }
      ////////////
      else if(n == 4) { stayStMen = false;exit(); }
      ////////////
      else { System.out.println("ERROR: Invalid option"); }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerLogin() throws ParseException
  {
    // set the login in path for customer
    boolean stayStLog = true;
    boolean correct = false;
    while(stayStLog == true)  {
      System.out.println("Username: ");
      String username = sc.next();
      System.out.println("Password: ");
      String password = sc.next();
      System.out.println(AirlineSystem.Customers.size());
      ////////////
      for (Customer st : AirlineSystem.Customers)
      {
        System.out.println(st.getUserName());
        ////////////
        if (username.equals(st.getUserName())
                && password.equals(st.getPassword()))
        { currentCustomer = st; correct = true; }
      }
      ////////////
      if(correct) { customerFlightMenu(); stayStLog = false; }
      ////////////
      else {
        System.out.println("Incorrect login info.");
        System.out.println("1. Try again");
        System.out.println("2. Register");
        System.out.println("3. Back");
        System.out.println("4. Close Program");

        int n = sc.nextInt(); sc.nextLine();

        if (n == 1) { }
        ////////////
        else if (n == 2)
        ////////////
        { customerRegister(); }
        ////////////
        else if(n == 3) { stayStLog = false; }
        ////////////
        else if(n == 4) { stayStLog = false; exit(); }
        ////////////
        else
        { System.out.println("ERROR: Choose valid option"); }
      }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerRegister() throws ParseException
  {
    boolean stayStReg = true;
    while(stayStReg) {
      stayStReg = false;
      String name = "";
      String username = "";
      String password = "";
      ////////////
      while(name.equals("")) {
        String first;
        String last;
        System.out.println("First name: ");
        first = sc.next();
        System.out.println("Last name: ");
        last = sc.next();
        name = first + " " + last;
      }
      ////////////
      while(username.equals("")) {
        System.out.println("Please enter a username: ");
        username = sc.next();
      }
      ////////////
      while(airSys.usernameExist(username))
      {
        System.out.println("ERROR: Username already exists");
        System.out.println("Please enter a username: ");
        username = sc.next();
      }

      System.out.println("Please enter a password: ");
      password = sc.next();

      // Will construct a new Customer with the given username,password and name and adds it to the list of customers
      Customer customer = new Customer(name, username, password);
      airSys.addCustomer(customer);
      ////////////
      try {
        Writing.writeInformation(AirlineSystem.getFlights(), AirlineSystem.Airlines, AirlineSystem.getCustomers());
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      }
      customerLogin();
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerFlightMenu() throws ParseException
  {
    //var
    boolean stayStLoged = true;
    ////////////
    while(stayStLoged == true) {
      System.out.println(currentCustomer.getName() + " please enter the number of the desired option");
      System.out.println("1. Search your landing location");
      System.out.println("2. Search place you leave from");
      System.out.println("3. Search Flight Number");
      System.out.println("4. See all flights ");
      System.out.println("5. See your flights");
      System.out.println("6. Book a flight");
      System.out.println("7. Cancel flight");
      System.out.println("8. Logout");
      System.out.println("9. Close Program");

      int n = sc.nextInt(); sc.nextLine();
      ////////////
      if (n == 1)
      {
        System.out.println("Enter name of place u want to go (Chicago, Atlanta, London, Springfield, NewYork): ");
        String landing = sc.nextLine();
        ////////////
        if(!airSys.FlightLandingExist(landing))
        { System.out.println("ERROR: Place does not exist"); }
        ////////////
        airSys.searchLanding(landing);
      }
      /////////////
      else if (n == 2)
      {
        System.out.println("Enter the name of place you are leaving from (Chicago, Atlanta, London, Springfield, NewYork): ");
        String takeOff = sc.next();
        if(!airSys.FlightTakeOffExist(takeOff))
        { System.out.println("ERROR: Place does not exist"); }
        ////////////
        airSys.searchTakeOff(takeOff);
      }
      ////////////
      else if (n == 3)
      {
        System.out.println("Enter Flight Number: ");
        int num = sc.nextInt(); sc.nextLine();
        if(!airSys.FlightNumExist(num))
        { System.out.println("ERROR: Flight does not exist"); }
        ////////////
        airSys.searchNum(num);
      }
      else if (n == 4) { airSys.displayAll();}
      ////////////
      else if(n == 5) {
        ////////////
        for(Flight item : currentCustomer.getCheckFlight()) {
          System.out.println(item);
        }
      }
      ////////////
      else if (n == 6) {
        ////////////
        if(!currentCustomer.getFlightStatus()) { customerCheckoutFlight(); }
        ////////////
        else { System.out.println("Payment needed"); }
        ////////////
      }
      ////////////
      else if (n == 7) { customerReturnFlight(); }
      ////////////
      else if(n == 8) { stayStLoged = false; }
      ////////////
      else if(n == 9) { stayStLoged = false; exit(); }
      ////////////
      else if (n < 1 || n > 9)
      { System.out.println("Invalid input"); }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerCheckoutFlight()
  {
    System.out.println("Please enter the flight number to book: ");
    int ISB = sc.nextInt();
    sc.nextLine();
    Flight currentFlight = airSys.getFlight(ISB);
    ////////////
    if(currentFlight != null
            && currentFlight.getAvailableStatus()) {
      currentCustomer.rentFlight(currentFlight);
      int numOfDays = 0; //zero day = pay that day
      Calendar cal = Calendar.getInstance();
      cal.add(Calendar.DAY_OF_YEAR, numOfDays);
      currentFlight.setflightDate(cal.getTime());
      System.out.println("You have booked flight: " + currentFlight.toString());
    }
    ////////////
    else if(currentFlight != null
            && !currentFlight.getAvailableStatus()){
      System.out.println("Flight  is currently unavailable.");
    }
    ////////////
    else {
      System.out.println("Number does not match any flights we have.");
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void customerReturnFlight() {
    System.out.println("Which Flight would you like to cancel?");
    for(Flight item : currentCustomer.getCheckFlight()) {
      System.out.println(item);
    }
    ////////////
    System.out.println("Please enter the date of the flight to cancel: ");
    int ISB = sc.nextInt();
    sc.nextLine();
    Flight currentFlight = airSys.getFlight(ISB);
    currentCustomer.turnInFlight(currentFlight);
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void airlineLogin() throws ParseException
  {
    boolean stayLibLog = true;
    boolean correct = false;
    while(stayLibLog) {
      // Ask the user for login info
      //has temp pas word
      System.out.println("First time? ");
      System.out.println("temp username: 8 ");
      System.out.println("temp password: 8 ");
      System.out.println("Username: ");
      String username = sc.next();
      System.out.println("Password: ");
      String password = sc.next();
      for (Airline lib : AirlineSystem.Airlines)
      {
        ////////////
        if (username.equals(lib.getUserName()) && password.equals(lib.getPassword()))
        { currentAirline = lib; correct = true; } // Transfers them to the menu to search for books
      }
      ////////////
      if(correct) { airlineFlightMenu(); stayLibLog = false; }
      ////////////
      else {
        boolean correctInput = false;
        while(!correctInput) {
          System.out.println("Incorrect login info.");
          System.out.println("1. Try again");
          System.out.println("2. Back");
          System.out.println("3. Exit program");

          int n = sc.nextInt(); sc.nextLine();

          if (n == 1) { correctInput = true; }
          ////////////
          else if (n == 2)
          ////////////
          { stayLibLog = false; correctInput = true; }
          ////////////
          else if(n == 3) { stayLibLog = false; correctInput = true; exit(); }
          ////////////
          else { System.out.println("Invalid input"); }
        }
      }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void createAirline() {
    System.out.println("Please enter a name: ");
    String name = sc.nextLine();
    System.out.println("Please enter a username: ");
    String username = sc.next();
    ////////////
    while(airSys.usernameExist(username))
    {
      System.out.println("ERROR: Username currently exists");
      System.out.println("Please enter a username: ");
      username = sc.next();
    }
    ////////////
    System.out.println("Please enter a password: ");
    String password = sc.next();
    // constructs a new airline employee with the right login in info and adds it to the list of airline employees
    Airline lib = new Airline(name, username, password);
    AirlineSystem.addAirline(lib);
    ////////////
    try {
      Writing.writeInformation(AirlineSystem.getFlights(), AirlineSystem.Airlines, AirlineSystem.getCustomers());
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void airlineFlightMenu() throws ParseException
  {
    boolean stayLibFlight = true;
    while(stayLibFlight) {
      System.out.println("Please enter the number of the desired option");
      System.out.println("1. View all booked flights");
      System.out.println("2. Add flight to system");
      System.out.println("3. Search by landing location");
      System.out.println("4. Search by take off locations");
      System.out.println("5. Search by flight number");
      System.out.println("6. Register new Airlines employee");
      System.out.println("7. Logout");
      System.out.println("8. Exit program");

      int n = sc.nextInt(); sc.nextLine();

      if (n == 1)
      { currentAirline.getCheckedFlights();  }
      ////////////
      else if (n == 2)
      {
        System.out.println("Enter landing location: ");
        String landing = sc.nextLine();
        System.out.println("Enter take off location: ");
        String takeOff = sc.nextLine();

        int num = 0;
        ////////////
        for(Flight item : AirlineSystem.getFlights()) {
          ////////////
          if(item.getNum() > num) { num = item.getNum(); }
        }
        num++;
        fl = new Flight(takeOff, num, landing);
        airSys.addFlight(fl);
        ////////////
        try {
          Writing.writeInformation(AirlineSystem.getFlights(),
                  AirlineSystem.Airlines,
                  AirlineSystem.getCustomers());
        } catch (ClassNotFoundException e) {
          e.printStackTrace();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
      ////////////
      else if (n == 3) {
        System.out.println("Enter take landing location: ");
        String landing = sc.nextLine();
        airSys.searchLanding(landing);
      }
      ////////////
      else if (n == 4) {
        System.out.println("Enter take off location: ");
        String takeOff = sc.nextLine();

        airSys.searchTakeOff(takeOff);
      }
      ////////////
      else if (n == 5)
      {
        System.out.println("Enter flight number: ");
        int num = sc.nextInt(); sc.nextLine();
        airSys.searchNum(num);
      }
      ////////////
      else if (n == 6) {
        createAirline();
      }
      ////////////
      else if (n == 7) {
        stayLibFlight = false;
      }
      ////////////
      else if (n == 8) {
        stayLibFlight = false;
        exit();
      }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void airlineFlightMenu2()
  {
    System.out.println("What would you like to do with the Flight?");
    System.out.println("1. View Flight status");
    System.out.println("2. Delete Flight from system");

    int n = sc.nextInt(); sc.nextLine();

    if (n == 1)
    {
      ////////////
      if (fl.getAvailableStatus() == true)
      {
        System.out.println("Flight is available");
      }
      ////////////
      else
      {
        System.out.println("Flight is not available");
      }
    }
    ////////////
    else if (n == 2)
    {
      currentAirline.deleteFlight(fl); // Add flight as instance variable?
      ////////////
      try {
        Writing.writeInformation(AirlineSystem.getFlights(), AirlineSystem.Airlines, AirlineSystem.getCustomers());
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public void exit() throws ParseException
  {
    System.out.println("1. Return to main menu");
    System.out.println("2. Exit program");
    int n = sc.nextInt(); sc.nextLine();
    ////////////
    if(n == 1) {
      menu();
    }
    ////////////
    try {
      Writing.writeInformation(AirlineSystem.getFlights(), AirlineSystem.Airlines, AirlineSystem.getCustomers());
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
    System.exit(0);
  }


  ////////////////////////////////////////////////////////////////////////////////////
  public static void main(String[] args) throws ParseException
  { Menu menu = new Menu(); }
}
