import java.util.Random;
import java.text.ParseException;
import java.util.Date;
public class Flight
{

    private String Landing; //Landing of the Flight
    private Boolean availableStatus; //true = available
    private String TakeOff; //name of the takeOff
    private int flightNumN; //the Flight num
    private DateAirline flightDate; //date of flight
    private int IdForPay; //pay number
    Random rand = new Random();
    int temp = rand.nextInt(9000000) + 1000000;

    ////////////////////////////////////////////////////////////////////////////////////

    public Flight(String takeOff, int Num, String Landing) throws ParseException
    {
        this.TakeOff = takeOff;
        this.flightNumN = Num;
        this.Landing = Landing;
        availableStatus = true;
        flightDate = new DateAirline();
    }

    ////////////////////////////////////////////////////////////////////////////////////
   //get take off
    public String getTakeOff()
    {return TakeOff;}

    ////////////////////////////////////////////////////////////////////////////////////
    //get num for flight
    public int getNum()
    {return flightNumN;}


    ////////////////////////////////////////////////////////////////////////////////////
    //get landing
    public String getLanding()
    {return Landing;}


    ////////////////////////////////////////////////////////////////////////////////////
    //get available
    public Boolean getAvailableStatus()
    {return availableStatus;}


    ////////////////////////////////////////////////////////////////////////////////////
    public void setAvailableStatus(Boolean stat)
    { availableStatus = stat; }


    ////////////////////////////////////////////////////////////////////////////////////
    //get the date
    public DateAirline getDate()
    {return flightDate;}


    ////////////////////////////////////////////////////////////////////////////////////
    //set the flight date
    public void setflightDate(Date d)
    { flightDate.setFlightDate(d); }


    ////////////////////////////////////////////////////////////////////////////////////
    public String toString()
    { return ("TakeOff: " + TakeOff + " Landing: " + Landing + " Num: " + flightNumN); }

}
