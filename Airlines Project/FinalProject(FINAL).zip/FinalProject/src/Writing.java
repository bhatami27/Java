import java.io.*;
import java.util.*;

public class Writing implements Serializable{

    ////////////////////////////////////////////////////////////////////////////////////

    public Writing() throws ClassNotFoundException, IOException
    {
        ArrayList<Flight> bk = new ArrayList<Flight>();
        ArrayList<Airline> lb = new ArrayList<Airline>();
        ArrayList<Customer> std = new ArrayList<Customer>();
        bk = AirlineSystem.allFlights;
        lb = AirlineSystem.Airlines;
        std = AirlineSystem.Customers;
        Writing.writeInformation(bk, lb, std);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void main(String[] args) throws ClassNotFoundException, IOException { }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void writeInformation(ArrayList<Flight> bk, ArrayList<Airline> lbs, ArrayList<Customer> std) throws IOException, ClassNotFoundException {
        writeAirline(lbs, "Airline.txt");
        writeCustomer(std, "Customer.txt");
        writeFlight(bk, "Flight.txt");
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void writeCustomer(ArrayList<Customer> std, String filename) {
        String out = "";
        for (Customer st : std) {
            String fn = Writing.createHash(16) + ".txt";
            out += (out.length() == 0 ? "" : "\n") + (st.getName() + "\t" + st.getUserName() + "\t" + st.getPassword() + "\t" + fn + "\t" + st.getFlightFee() + "\t" + st.getFlightStatus());
            Writing.writeFlight(st.getCheckFlight(), fn);
        }
        Writing.writeFile(filename, out);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void writeFlight(ArrayList<Flight> bk, String filename) {
        String out = "";
        for (Flight book : bk) {
            out += (out.length() == 0 ? "" : "\n") + (book.getTakeOff() + "\t" + book.getNum() + "\t" + book.getLanding());
        }
        Writing.writeFile(filename, out);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void writeAirline(ArrayList<Airline> lbs, String filename) {
        String out = "";
        for (Airline lb : lbs)
        {
            String fn = Writing.createHash(16) + ".txt";
            out += (out.length() == 0 ? "" : "\n") + (lb.getName() + "\t" + lb.getUserName() + "\t" + lb.getPassword() + "\t" + fn);
            Writing.writeFlight(lb.getCheckedFlights(), fn);
        }
        Writing.writeFile(filename, out);
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static void writeFile(String filename, String text) {
        BufferedWriter writer;
        try {
            writer = new BufferedWriter(new FileWriter(new File(filename)));
            writer.write(text);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////
    public static String createHash(int size) {
        String res = "";
        String abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        for (int i = 0; i < size; i++)
            res += abc.charAt(new Random().nextInt(abc.length()));

        return res;
    }

}
